package com.library.main;
import com.library.dao.BookDAO;
import com.library.model.Book;
import java.util.List;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        BookDAO dao = new BookDAO();

	        while (true) {
	            System.out.println("\n1. Add Book");
	            System.out.println("2. View Books");
	            System.out.println("3. Issue Book");
	            System.out.println("4. Delete Book");
	            System.out.println("5. Exit");

	            int choice = sc.nextInt();
	            sc.nextLine();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter title: ");
	                    String title = sc.nextLine();

	                    System.out.print("Enter author: ");
	                    String author = sc.nextLine();

	                    dao.addBook(new Book(title, author, false));
	                    break;

	                case 2:
	                    List<Book> books = dao.getAllBooks();
	                    for (Book b : books) {
	                        System.out.println(b.getId() + " " + b.getTitle() + " " + b.getAuthor() + " Issued: " + b.isIssued());
	                    }
	                    break;

	                case 3:
	                    System.out.print("Enter Book ID: ");
	                    int id = sc.nextInt();
	                    dao.issueBook(id);
	                    break;

	                case 4:
	                    System.out.print("Enter Book ID: ");
	                    int delId = sc.nextInt();
	                    dao.deleteBook(delId);
	                    break;

	                case 5:
	                    System.exit(0);
	            }
	        }
	    }
	

	}


